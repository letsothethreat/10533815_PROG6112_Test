/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingconsolereport;

/**
 *
 * @author Student
 */
public class GamingConsoleReport {

    public static void main(String[] args) {
        
       System.out.println("----------------------------------------------------------");
       System.out.println("GAMING CONSOLE REPORT");
       System.out.println("----------------------------------------------------------");
       
       //print 2D array to store each console sale 
       int [][] sales = {
           {1000, 2000, 3000}, //CPT
           {2000, 3000, 4000}, //PE
           {1500, 1100, 1200}  //PTA
       };
       
     
       // Single dimensional array for the cities
       String[] cities = {"CAPE TOWN", "PORT ELIZABETH", "PRETORIA"};

   

        String[] consoleTypes = {"PS5", "XBOX", "SWITCH"};

        // For totals and most sales
        int[] totalSalesPerCity = new int[cities.length];
        int maxSales = 0;
        String cityWithMostSales = "";

        // Calculating the total sales for each city
        for (int i = 0; i < cities.length; i++) {
            int total = 0;
            for (int j = 0; j < sales[i].length; j++) {
                total += sales[i][j];
            }
            totalSalesPerCity[i] = total;

            // Check for city with most sales
            if (total > maxSales) {
                maxSales = total;
                cityWithMostSales = cities[i];
            }
        }

        //DISPLAY REPORT
        System.out.printf("%-20s %-8s %-8s %-8s\n", "", consoleTypes[0], consoleTypes[1], consoleTypes[2]);

        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-20s %-8d %-8d %-8d\n", cities[i], sales[i][0], sales[i][1], sales[i][2]);
        }

        System.out.println("-----------------------------------------------------------");
        System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
        System.out.println("-----------------------------------------------------------");
        System.out.println("");

        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-20s %d\n", cities[i], totalSalesPerCity[i]);
        }

        System.out.println("");
        System.out.println("CITY WITH THE MOST SALES: " + cityWithMostSales);
        System.out.println("");
        System.out.println("-----------------------------------------------------------");
    }
}

