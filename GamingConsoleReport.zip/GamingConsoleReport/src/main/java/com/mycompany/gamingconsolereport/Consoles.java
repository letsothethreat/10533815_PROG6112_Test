
package com.mycompany.gamingconsolereport;

/**
 *
 * @author Student
 */
public abstract class Consoles implements IConsoles{
 	protected String consoleType;
	protected String storeName;
	protected int totalSales;

	//Constructor that accepts the console type, store name and total amount of sales as parameters
	public Consoles(String consoleType, String storeName, int totalSales){
		this.consoleType = consoleType;
		this.storeName = storeName;
		this.totalSales = totalSales;
	}
 
	//This is the method to get the console type, store name, and total amount of sales
	@Override
	public String getConsoleType() {
		return consoleType;
	}

	@Override
	public String getStore() {
		return storeName;
	}

	@Override
	public String getTotalSales() {
		return totalSales;
	}

	public abstract void printReport();

}
