import java.util.Scanner;

public class RunApplication {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Select the beverage type");
        System.out.println("1) PS5");
        System.out.println("2) XBOX");
        System.out.println("3) SWITCH");
        System.out.println("");

        int choice = input.nextInt();
        input.nextLine(); // consume enter

        String consoleType = "";
        switch (choice) {
            case 1: consoleType = "PS5"; break;
            case 2: consoleType = "XBOX"; break;
            case 3: consoleType = "SWITCH"; break;
            default: consoleType = "PS5"; break;
        }

        System.out.print("Enter the store: ");
        String storeName = input.nextLine();

        System.out.print("Enter the total sales of " + consoleType + " consoles for " + storeName + ":");
        int totalSales = input.nextInt();

        // Instantiate the ConsoleSales class
        ConsoleSales salesReport = new ConsoleSales(consoleType, storeName, totalSales);

        // Print the report
        salesReport.printReport();

        input.close();
    }
}

