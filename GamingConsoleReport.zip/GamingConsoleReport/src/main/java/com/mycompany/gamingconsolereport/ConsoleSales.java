
package com.mycompany.gamingconsolereport;

/**
 *
 * @author Student
 */
public class ConsoleSales extends Consoles {

    // Constructor to accept console type, store name, total amount
    public ConsoleSales(String consoleType, String storeName, int totalSales) {
        super(consoleType, storeName, totalSales);
    }

    // printReport method which prints the console type, store name, total sales
    @Override
    public void printReport() {
        System.out.println("\nCONSOLE SALES REPORT");
        System.out.println("****************");
        System.out.println("CONSOLE TYPE: " + getConsoleType());
        System.out.println("STORE: " + getStore());
        System.out.println("TOTAL SALES: " + getTotalSales());
    }
}

